//@ui5-bundle com/sap/uiauxiliar/Component-preload.js
sap.ui.require.preload({
	"com/sap/uiauxiliar/Component.js":function(){
sap.ui.define(["sap/ui/core/UIComponent","sap/ui/Device","com/sap/uiauxiliar/model/models"],function(e,i,t){"use strict";return e.extend("com.sap.uiauxiliar.Component",{metadata:{manifest:"json"},init:function(){e.prototype.init.apply(this,arguments);this.getRouter().initialize();this.setModel(t.createDeviceModel(),"device")}})});
},
	"com/sap/uiauxiliar/controller/App.controller.js":function(){
sap.ui.define(["com/sap/uiauxiliar/controller/BaseController"],function(e){"use strict";return e.extend("com.sap.uiauxiliar.controller.App",{onInit(){this._userModel=this.getOwnerComponent().getModel("userModel");let e=this;fetch("/myext").then(e=>e.json()).then(o=>{e._userModel.setProperty("/",o);console.log(e._userModel.getProperty("/"))}).catch(e=>console.log(e))}})});
},
	"com/sap/uiauxiliar/controller/BaseController.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller","sap/ui/core/routing/History","sap/ui/core/UIComponent","com/sap/uiauxiliar/model/formatter"],function(e,t,o,n){"use strict";return e.extend("com.sap.uiauxiliar.controller.BaseController",{formatter:n,getModel:function(e){return this.getView().getModel(e)},setModel:function(e,t){return this.getView().setModel(e,t)},getResourceBundle:function(){return this.getOwnerComponent().getModel("i18n").getResourceBundle()},navTo:function(e,t,o){this.getRouter().navTo(e,t,o)},getRouter:function(){return o.getRouterFor(this)},onNavBack:function(){var e=t.getInstance().getPreviousHash();if(e!==undefined){window.history.back()}else{this.getRouter().navTo("appHome",{},true)}}})});
},
	"com/sap/uiauxiliar/i18n/i18n.properties":'title=com.sap.AgroNegocios\nappTitle=com.sap.AgroNegocios\nappDescription=App Description Agronegocios\n\n',
	"com/sap/uiauxiliar/i18n/i18n_en.properties":'title=com.sap.AgroNegocios\nappTitle=com.sap.AgroNegocios\nappDescription=App Description Agronegocios',
	"com/sap/uiauxiliar/manifest.json":'{"_version":"1.49.0","sap.app":{"id":"com.sap.uiauxiliar","type":"application","i18n":"i18n/i18n.properties","applicationVersion":{"version":"0.0.1"},"title":"{{appTitle}}","description":"{{appDescription}}","resources":"resources.json","sourceTemplate":{"id":"@sap/generator-fiori:basic","version":"1.11.1","toolsId":"a122481a-4937-4f5e-9652-6f7628418dca"},"crossNavigation":{"inbounds":{"uiauxiliar-display":{"semanticObject":"uiauxiliar","action":"display","title":"My Demo Agronegocios Application","subTitle":"Subtitulo","signature":{"parameters":{},"additionalParameters":"allowed"}}}}},"sap.ui":{"technology":"UI5","icons":{"icon":"","favIcon":"","phone":"","phone@2":"","tablet":"","tablet@2":""},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"flexEnabled":true,"dependencies":{"minUI5Version":"1.118.1","libs":{"sap.m":{},"sap.ui.core":{},"sap.f":{},"sap.suite.ui.generic.template":{},"sap.ui.comp":{},"sap.ui.generic.app":{},"sap.ui.table":{},"sap.ushell":{}}},"contentDensities":{"compact":true,"cozy":true},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"com.sap.uiauxiliar.i18n.i18n"}},"userModel":{"type":"sap.ui.model.json.JSONModel"}},"resources":{"css":[{"uri":"css/style.css"}]},"routing":{"config":{"routerClass":"sap.m.routing.Router","viewType":"XML","async":true,"viewPath":"com.sap.uiauxiliar.view","controlAggregation":"pages","controlId":"idApp","clearControlAggregation":false},"routes":[{"name":"RouteApp","pattern":"RouteApp","target":["TargetView1"]}],"targets":{"TargetView1":{"viewType":"XML","transition":"slide","clearControlAggregation":false,"viewId":"idApp","viewName":"App"}}},"rootView":{"viewName":"com.sap.uiauxiliar.view.App","type":"XML","async":true,"id":"idApp"}}}',
	"com/sap/uiauxiliar/model/formatter.js":function(){
sap.ui.define([],function(){"use strict";return{}});
},
	"com/sap/uiauxiliar/model/models.js":function(){
sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(e,n){"use strict";return{createDeviceModel:function(){var i=new e(n);i.setDefaultBindingMode("OneWay");return i}}});
},
	"com/sap/uiauxiliar/view/App.view.xml":'<mvc:View controllerName="com.sap.uiauxiliar.controller.App"\n    xmlns:html="http://www.w3.org/1999/xhtml"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><App id="idApp"></App></mvc:View>\n'
});
//# sourceMappingURL=Component-preload.js.map
