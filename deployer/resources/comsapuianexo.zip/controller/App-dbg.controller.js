sap.ui.define(
  [
    "com/sap/uianexo/controller/BaseController"
  ],
  function(BaseController) {
    "use strict";
  

    return BaseController.extend("com.sap.uianexo.controller.App", {
      onInit() {
    




      }
      //,
    //   onPressButton: function() {
    //     alert('probando button');
        
    //     window.location.replace("https://dekatest.dekagb.com/dkAGRObit_TEST/smartfarm/newdasH");
        
        
    //   }
     });
  }
);
