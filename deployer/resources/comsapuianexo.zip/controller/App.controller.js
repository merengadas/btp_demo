sap.ui.define(["com/sap/uianexo/controller/BaseController"],function(e){"use strict";return e.extend("com.sap.uianexo.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map