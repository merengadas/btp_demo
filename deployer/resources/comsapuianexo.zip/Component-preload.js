//@ui5-bundle com/sap/uianexo/Component-preload.js
sap.ui.require.preload({
	"com/sap/uianexo/Component.js":function(){
sap.ui.define(["sap/ui/core/UIComponent","sap/ui/Device","com/sap/uianexo/model/models"],function(e,i,t){"use strict";return e.extend("com.sap.uianexo.Component",{metadata:{manifest:"json"},init:function(){e.prototype.init.apply(this,arguments);this.getRouter().initialize();this.setModel(t.createDeviceModel(),"device")}})});
},
	"com/sap/uianexo/controller/App.controller.js":function(){
sap.ui.define(["com/sap/uianexo/controller/BaseController"],function(e){"use strict";return e.extend("com.sap.uianexo.controller.App",{onInit(){}})});
},
	"com/sap/uianexo/controller/BaseController.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller","sap/ui/core/routing/History","sap/ui/core/UIComponent","com/sap/uianexo/model/formatter"],function(e,t,o,n){"use strict";return e.extend("com.sap.uianexo.controller.BaseController",{formatter:n,getModel:function(e){return this.getView().getModel(e)},setModel:function(e,t){return this.getView().setModel(e,t)},getResourceBundle:function(){return this.getOwnerComponent().getModel("i18n").getResourceBundle()},navTo:function(e,t,o){this.getRouter().navTo(e,t,o)},getRouter:function(){return o.getRouterFor(this)},onNavBack:function(){var e=t.getInstance().getPreviousHash();if(e!==undefined){window.history.back()}else{this.getRouter().navTo("appHome",{},true)}}})});
},
	"com/sap/uianexo/i18n/i18n.properties":'title=com.sap.mydemoLogistica\nappTitle=com.sap.mydemoLogistica\nappDescription=App Description Logistica\nflpTitle=ccc\nflpSubtitle=xxx\n',
	"com/sap/uianexo/i18n/i18n_en.properties":'title=com.sap.Logistica\nappTitle=com.sap.Logistica\nappDescription=App Description Logistica',
	"com/sap/uianexo/i18n/i18n_es_ES.properties":'title=com.sap.Agrobit\nappTitle=com.sap.Agrobit\nappDescription=App Description Agrobit\n',
	"com/sap/uianexo/manifest.json":'{"_version":"1.49.0","sap.app":{"id":"com.sap.uianexo","type":"application","i18n":"i18n/i18n.properties","applicationVersion":{"version":"0.0.1"},"title":"{{appTitle}}","description":"{{appDescription}}","resources":"resources.json","sourceTemplate":{"id":"@sap/generator-fiori:basic","version":"1.11.1","toolsId":"c63ab96e-fbbf-428f-8431-33eec69b5cfb"},"crossNavigation":{"inbounds":{"uianexo-display":{"semanticObject":"uianexo","action":"display","title":"My Demo Logistica Application","subTitle":"Subtitulo","signature":{"parameters":{},"additionalParameters":"allowed"}}}}},"sap.ui":{"technology":"UI5","icons":{"icon":"","favIcon":"","phone":"","phone@2":"","tablet":"","tablet@2":""},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"flexEnabled":true,"dependencies":{"minUI5Version":"1.118.1","libs":{"sap.m":{},"sap.ui.core":{},"sap.f":{},"sap.suite.ui.generic.template":{},"sap.ui.comp":{},"sap.ui.generic.app":{},"sap.ui.table":{},"sap.ushell":{}}},"contentDensities":{"compact":true,"cozy":true},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"com.sap.uianexo.i18n.i18n","supportedLocales":[""],"fallbackLocale":""}},"userModel":{"type":"sap.ui.model.json.JSONModel"},"userModel1":{"type":"sap.ui.model.json.JSONModel"},"userModel2":{"type":"sap.ui.model.json.JSONModel"}},"resources":{"css":[{"uri":"css/style.css"}]},"routing":{"config":{"routerClass":"sap.m.routing.Router","viewType":"XML","async":true,"viewPath":"com.sap.uianexo.view","controlAggregation":"pages","controlId":"idAppAnexo","clearControlAggregation":false},"routes":[{"name":"RouteApp","pattern":"RouteApp","target":["TargetView11"]}],"targets":{"TargetView11":{"viewType":"XML","transition":"slide","clearControlAggregation":false,"viewId":"idAppAnexo","viewName":"App"}}},"rootView":{"viewName":"com.sap.uianexo.view.App","type":"XML","async":true,"id":"idAppAnexo"}}}',
	"com/sap/uianexo/model/formatter.js":function(){
sap.ui.define([],function(){"use strict";return{}});
},
	"com/sap/uianexo/model/models.js":function(){
sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(e,n){"use strict";return{createDeviceModel:function(){var i=new e(n);i.setDefaultBindingMode("OneWay");return i}}});
},
	"com/sap/uianexo/view/App.view.xml":'<mvc:View controllerName="com.sap.uianexo.controller.App"\n    xmlns:html="http://www.w3.org/1999/xhtml"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><App id="idAppAnexo" ></App></mvc:View>\n'
});
//# sourceMappingURL=Component-preload.js.map
