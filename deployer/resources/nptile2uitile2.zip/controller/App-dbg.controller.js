sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("nptile2.uitile2.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  